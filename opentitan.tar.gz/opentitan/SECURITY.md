If you have discovered a security vulnerability, we appreciate your help by disclosing it to us in a responsible manner.
Please refer to https://opentitan.org/cvd-policy for a description of our disclosure process.

List of Fingerprints for current selection of authentic PGP keys to be used for encrypting communication of vulnerabilities to OpenTitan:
* 5C74 B08E 288D 5FD6 69BE  218D 39CD 4C54 4C96 B543
* D2E1 ACBE 6923 D2E6 F3B6  8489 3AB6 80B2 B761 16AE
* F0B1 4C4F 23FF 4683 55B5  CC91 E39C 8B86 8A28 F643
* D920 BB42 8DD2 894A A58B  B179 3B13 03ED 7C0E 8B4A
* 0A1E 80C4 31E1 2E0A F3E4  C5A9 5943 8153 1326 3D11
* A8BC 562A 709B B45D 7BA2  A12E A28F 0969 A753 0E42
* A104 7CC3 90E4 0B29 8A72  DC24 8245 CE65 8101 F3C2
