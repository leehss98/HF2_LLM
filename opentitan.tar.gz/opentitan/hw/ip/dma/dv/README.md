# DMA DV document

## Testbench architecture

The DMA testbench has been constructed based on the [CIP testbench architecture](../../../dv/sv/cip_lib/README.md).

### Block diagram

![Block diagram](./doc/tb.svg)

## Testplan

[Testplan](../data/dma_testplan.hjson)
