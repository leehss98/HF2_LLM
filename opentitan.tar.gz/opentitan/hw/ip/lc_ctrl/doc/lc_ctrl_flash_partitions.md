<table>
<thead>
<tr>
<th>Collateral</th>
<th>Partition</th>
<th>Memory Mapped?</th>
</tr>
</thead>
<tbody>
<tr>
<td>CREATOR_DIV_KEY</td>
<td>CREATOR_DATA partition</td>
<td>No</td>
</tr>
<tr>
<td>OWNER_ROOT_SECRET</td>
<td>OWNER_DATA partition</td>
<td>No</td>
</tr>
</tbody>
</table>
