# I2C DV UVM Agent

I2C UVM Agent is extended from DV library agent classes.
