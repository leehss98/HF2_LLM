# PWM UVM Monitor

PWM UVM Monitor is extended from DV library agent classes.
